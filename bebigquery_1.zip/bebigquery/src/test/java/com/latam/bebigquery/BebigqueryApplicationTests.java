package com.latam.bebigquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BebigqueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
